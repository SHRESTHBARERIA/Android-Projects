package com.example.bloodbank;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class donor extends AppCompatActivity {
    EditText names, location, adhaar, numb;
    Button register;
    Spinner state, bgroup;
    DatabaseReference adddonordetails;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_donor);
        names = findViewById(R.id.name);
        adhaar = findViewById(R.id.adhaar);
        location = findViewById(R.id.loca);
        numb = findViewById(R.id.contact);
        state = findViewById(R.id.state);
        bgroup = findViewById(R.id.bloodgroup);
        register = findViewById(R.id.sign_in);
        adddonordetails = FirebaseDatabase.getInstance().getReference("donor");
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                adddonordetails();

            }
        });
    }

  private void adddonordetails() {
        String Name = names.getText().toString().trim();
        String location_details = location.getText().toString().trim();
        String adhaar_number = adhaar.getText().toString().trim();
        String number = numb.getText().toString().trim();
        String states = state.getSelectedItem().toString();
        String blood_group = bgroup.getSelectedItem().toString();

            if (TextUtils.isEmpty(Name))
                {
                Toast.makeText(donor.this, "Please Enter names", Toast.LENGTH_SHORT).show();
                }
                else if (TextUtils.isEmpty(location_details))
                {
                Toast.makeText(donor.this, "Please Enter address", Toast.LENGTH_SHORT).show();
                }
                 else if (TextUtils.isEmpty(number))
                {
                Toast.makeText(donor.this, "Please Enter your number", Toast.LENGTH_SHORT).show();
                 }

                 else if (TextUtils.isEmpty(adhaar_number))
                {
                 Toast.makeText(donor.this, "Please Enter the adhaar number", Toast.LENGTH_SHORT).show();
                 }
                 else if (number.length() < 10)
                {
                Toast.makeText(donor.this, "Enter correct number", Toast.LENGTH_SHORT).show();
                 }
                 else if (adhaar_number.length() < 12)
                {
                Toast.makeText(donor.this, "Enter correct adhaar number", Toast.LENGTH_SHORT).show();
                 }

                        else
                            {
                String id = adddonordetails.push().getKey();
                data_storage ds = new data_storage(id, Name, location_details, adhaar_number, number, states, blood_group);
                adddonordetails.child(id).setValue(ds);
                Toast.makeText(donor.this, "id added", Toast.LENGTH_LONG).show();
            }
        }
    }