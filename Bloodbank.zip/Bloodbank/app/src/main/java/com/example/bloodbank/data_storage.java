package com.example.bloodbank;

public class data_storage {

    String bId;
    String Name;
    String states;
    String blood_group;
    String adhaar_number;
    String location_details;
    String number;


    public data_storage( ){


}

    public data_storage(String bId, String name, String states, String blood_group, String adhaar_number, String location_details, String number) {
        this.bId = bId;
        Name = name;
        this.states = states;
        this.blood_group = blood_group;
        this.adhaar_number = adhaar_number;
        this.location_details = location_details;
        this.number = number;
    }

    public String getbId() {
        return bId;
    }

    public String getName() {
        return Name;
    }

    public String getStates() {
        return states;
    }

    public String getBlood_group() {
        return blood_group;
    }

    public String getAdhaar_number() {
        return adhaar_number;
    }

    public String getLocation_details() {
        return location_details;
    }

    public String getNumber() {
        return number;
    }
}



