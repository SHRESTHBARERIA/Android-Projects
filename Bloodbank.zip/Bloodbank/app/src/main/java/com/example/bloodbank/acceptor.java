package com.example.bloodbank;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.List;

public class acceptor extends AppCompatActivity {
    Button fetch;
    Spinner bgroup;
    ListView donorss;
    List<data_storage> donorList;
    DatabaseReference addacceptordetails;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_donor);
        addacceptordetails = FirebaseDatabase.getInstance().getReference("acceptor");
        bgroup = findViewById(R.id.bloodgroup);
         donorss=findViewById(R.id.donors);
        fetch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addAcceptor();
            }
        });
    }

    private void addAcceptor() {
        super.onStart();
        addacceptordetails.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                donorList.clear();

                for (DataSnapshot donorSnapshot : dataSnapshot.getChildren()){
                    data_storage donor = donorSnapshot.getValue(data_storage.class);
                    donorList.add(donor);

                }

                donor_list adapter = new donor_list(acceptor.this, donorList);
                donorss.setAdapter(adapter);
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }
}
