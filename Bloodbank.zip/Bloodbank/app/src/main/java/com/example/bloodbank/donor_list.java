package com.example.bloodbank;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class donor_list extends ArrayAdapter <data_storage>{
    private Activity context;
    private List<data_storage> donorList;

    public donor_list(Activity context ,List<data_storage> donorList){
        super(context,R.layout.list_layout,donorList);
        this.context=context;
       this.donorList=donorList;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater=context.getLayoutInflater();
        View ListViewItem=inflater.inflate(R.layout.list_layout,null,true);
        TextView textname= (TextView) ListViewItem.findViewById(R.id.view0);
        data_storage donor=donorList.get(position);
        textname.setText(donor.getName());
        return ListViewItem;
    }
}
